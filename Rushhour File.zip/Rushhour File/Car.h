#pragma once
#include "Consola.h"
#include <conio.h>
#include <iostream>
using namespace std;
class Car
{
protected:
	int x;
	int y;
	int num;
	int color;
public:
	void printCar();
	Car(int _x, int _y, int _num, int _color) {
		this->x = _x;
		this->y = _y;
		this->num = _num;
		this->color = _color;
	}
};

