#include "Car.h"
void Car::printCar() {
	int Carnum = num;
	int mapData[2][6]{
		2,2,2,2,3,3,
		2,2,2,2,3,3
	};
	for (int i = 0; i < 2; i++) {
		gotoxy(x, y + i);
		for (int j = 0; j < 6; j++) {
			if (mapData[i][j] == 3) {
				textbackground(BLUE); cout << " ";
			}
			else if (mapData[i][j] == 2) {
				textbackground(color); cout << " ";
			}
		}
	}
}