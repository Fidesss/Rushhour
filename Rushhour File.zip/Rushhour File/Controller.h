#pragma once
#include "View.h"
class Controller
{
	Model* _model;
	View* _view;
public:
	Controller() {
		_model = new Model;
		_view = new View;
	}
	~Controller() {
		delete _model;
		delete _view;
	}
	void start();
};

