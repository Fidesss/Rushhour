#include "Controller.h"
void Controller::start() {
	while (true) {
		_view->setting();
		_view->printMap();
		_model->_redCar->printCar();
		//sleep(10);
	}
}
