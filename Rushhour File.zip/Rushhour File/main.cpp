#include <iostream>
#include "Consola.h"
#include "Car.h"
#include "Controller.h"
#include <conio.h>

using namespace std;

int main() {
	Controller controller;
	controller.start();
	return 0;
}