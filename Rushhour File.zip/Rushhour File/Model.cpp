#include "Model.h"
Model::Model() {
	_redCar = new Car(10, 10, 1, 4);
}
Model::~Model() {
	delete _redCar;
}