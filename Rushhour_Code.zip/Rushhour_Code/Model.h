#pragma once
#include <iostream>
#include "Consola.h"
#include <conio.h>
#define MAX_WIDTH 28
#define MAX_HEIGHT 14

using namespace std;

class Model
{
protected:
	int x;
	int y;
	int num;
	int color;
public:
	void setting();
	void clearStr();
	void printMap();
};