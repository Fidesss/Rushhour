#pragma once
#define MAX_WIDTH = 5
#define MAX_HEIGHT = 10
class View
{
};

