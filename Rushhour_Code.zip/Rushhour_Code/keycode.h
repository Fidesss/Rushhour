	#pragma once
	#define LEFT_KEY 0xe04b
	#define RIGHT_KEY 0xe04d
	#define UP_KEY 0xe048
	#define DOWN_KEY 0xe050