#pragma once
#include "Consola.h"
#include "Model.h"
#include <conio.h>
#include <iostream>
using namespace std;
class Car
{protected:
	int x;
	int y;
	int num;
	int color;
public:
	void printCar(int x, int y, int num ,int color);
public:
	Car(int _x, int _y, int num, int color) {
		this->x = x;
		this->y = y;
		this->num = num;
		this->color = color;
	}
	Car() {
	}
};

